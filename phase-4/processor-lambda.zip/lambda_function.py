import json
import os
import tempfile
import requests

from processor import process_report


AWS_REGION = os.getenv(
    "AWS_REGION",
    "ap-south-1"
)

S3_BUCKET = os.getenv(
    "S3_BUCKET"
)

DIALOG360_API_KEY = os.getenv(
    "DIALOG360_API_KEY",
    "DUMMY_360DIALOG_API_KEY"
)

DIALOG360_BASE_URL = os.getenv(
    "DIALOG360_BASE_URL",
    "https://waba-v2.360dialog.io"
)


def lambda_handler(event, context):

    print(
        "[INFO] Processor Lambda started"
    )

    print(
        "[DEBUG] Event:",
        json.dumps(event)
    )

    try:

        media_id = event.get("media_id")
        sender = event.get("sender")
        message_id = event.get("message_id")

        if not media_id:
            raise ValueError(
                "Missing media_id in event"
            )

        print(
            f"[INFO] media_id={media_id}"
        )

        print(
            f"[INFO] sender={sender}"
        )

        print(
            f"[INFO] message_id={message_id}"
        )

        # --------------------------------------------------
        # STEP 1
        # Download image from 360dialog
        # --------------------------------------------------

        media_url = get_media_url(
            media_id
        )

        print(
            f"[INFO] Media URL obtained"
        )

        image_bytes, content_type = download_media(
            media_url
        )

        print(
            f"[INFO] Downloaded media: "
            f"{len(image_bytes)} bytes"
        )

        # --------------------------------------------------
        # STEP 2
        # Save temporary image
        # --------------------------------------------------

        extension = get_extension(
            content_type
        )

        with tempfile.NamedTemporaryFile(
            suffix=extension,
            delete=False
        ) as temp_file:

            temp_file.write(image_bytes)

            temp_image_path = temp_file.name

        print(
            f"[INFO] Temporary image: "
            f"{temp_image_path}"
        )

        # --------------------------------------------------
        # STEP 3
        # Extract report text
        # --------------------------------------------------

        from image_extractor import (
            extract_report_text
        )

        report_text = extract_report_text(
            temp_image_path
        )

        print(
            "[INFO] Report extraction completed"
        )

        print(
            "[DEBUG] Extracted report:"
        )

        print(report_text)

        # --------------------------------------------------
        # STEP 4
        # Run Phase 4 processor
        # --------------------------------------------------

        result = process_report(
            report_text
        )

        print(
            "[INFO] Phase 4 processing completed"
        )

        print(
            json.dumps(
                result,
                indent=2,
                ensure_ascii=False
            )
        )

        # --------------------------------------------------
        # STEP 5
        # Send result to WhatsApp
        # --------------------------------------------------

        if sender:

            send_whatsapp_message(
                sender,
                build_patient_message(result)
            )

        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "processed",
                "message_id": message_id
            })
        }

    except Exception as exc:

        print(
            f"[ERROR] Processor failed: {exc}"
        )

        raise


def get_media_url(media_id):

    url = (
        f"{DIALOG360_BASE_URL}"
        f"/media/{media_id}"
    )

    headers = {
        "D360-API-KEY": DIALOG360_API_KEY
    }

    response = requests.get(
        url,
        headers=headers,
        timeout=30
    )

    response.raise_for_status()

    data = response.json()

    media_url = data.get("url")

    if not media_url:
        raise RuntimeError(
            "360dialog response did not contain media URL"
        )

    return media_url


def download_media(media_url):

    headers = {
        "D360-API-KEY": DIALOG360_API_KEY
    }

    response = requests.get(
        media_url,
        headers=headers,
        timeout=60
    )

    response.raise_for_status()

    return (
        response.content,
        response.headers.get(
            "Content-Type",
            "image/jpeg"
        )
    )


def get_extension(content_type):

    content_type = (
        content_type
        .lower()
        .split(";")[0]
        .strip()
    )

    mapping = {
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/webp": ".webp",
        "image/gif": ".gif",
    }

    return mapping.get(
        content_type,
        ".jpg"
    )


def build_patient_message(result):

    explanation = result.get(
        "explanation",
        {}
    )

    summary = explanation.get(
        "summary",
        "Your report has been processed."
    )

    observations = explanation.get(
        "observations",
        []
    )

    lines = [
        "🧪 *Lab Report Summary*",
        "",
        summary,
        ""
    ]

    for observation in observations:

        name = observation.get(
            "name",
            "Test"
        )

        value = observation.get(
            "value",
            ""
        )

        comparison = observation.get(
            "comparison",
            ""
        )

        lines.append(
            f"• {name}: {value} "
            f"({comparison})"
        )

    lines.extend([
        "",
        "This is an educational explanation "
        "of the values shown in your report. "
        "It is not a medical diagnosis.",
        "",
        "Please discuss abnormal or concerning "
        "results with a qualified healthcare professional."
    ])

    return "\n".join(lines)


def send_whatsapp_message(
    recipient,
    message
):

    url = (
        f"{DIALOG360_BASE_URL}"
        "/messages"
    )

    headers = {
        "D360-API-KEY": DIALOG360_API_KEY,
        "Content-Type": "application/json"
    }

    payload = {
        "recipient_type": "individual",
        "to": recipient,
        "type": "text",
        "text": {
            "body": message
        }
    }

    response = requests.post(
        url,
        headers=headers,
        json=payload,
        timeout=30
    )

    response.raise_for_status()

    print(
        "[INFO] WhatsApp response:",
        response.text
    )